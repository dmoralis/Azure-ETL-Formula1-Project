-- Databricks notebook source
SHOW DATABASES

-- COMMAND ----------

SELECT current_database()

-- COMMAND ----------

USE f1_processed

-- COMMAND ----------

SHOW TABLES

-- COMMAND ----------

SELECT * FROM results LIMIT 10

-- COMMAND ----------

DESC TABLE results

-- COMMAND ----------

