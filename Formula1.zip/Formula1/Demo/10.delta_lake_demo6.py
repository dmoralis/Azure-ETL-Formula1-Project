# Databricks notebook source
# MAGIC %md Convert Parquet to Delta

# COMMAND ----------

