# Databricks notebook source
raw_folder_path = '/mnt/formula1dlmorales/raw'
processed_folder_path = '/mnt/formula1dlmorales/processed'
presentation_folder_path = '/mnt/formula1dlmorales/presentation'