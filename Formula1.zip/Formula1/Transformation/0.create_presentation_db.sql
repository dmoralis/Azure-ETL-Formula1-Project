-- Databricks notebook source
SHOW DATABASES;

-- COMMAND ----------

CREATE DATABASE f1_presentation
LOCATION "/mnt/formula1dlmorales/presentation/"

-- COMMAND ----------

SHOW DATABASES

-- COMMAND ----------

DESCRIBE DATABASE EXTENDED f1_presentation

-- COMMAND ----------

